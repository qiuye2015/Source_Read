
/*
 * Copyright (C) Igor Sysoev
 */



void *ngx_slab_alloc(ngx_slab_pool_t *pool, size_t size)
{
   return NULL;
}
