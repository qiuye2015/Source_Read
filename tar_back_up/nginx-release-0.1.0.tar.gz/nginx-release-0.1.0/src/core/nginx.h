
/*
 * Copyright (C) Igor Sysoev
 */


#ifndef _NGINX_H_INCLUDED_
#define _NGINX_H_INCLUDED_


#define NGINX_VER          "nginx/0.1.0"

#define NGINX_VAR          "NGINX"
#define NGX_NEWPID_EXT     ".newbin"


#endif /* _NGINX_H_INCLUDED_ */
