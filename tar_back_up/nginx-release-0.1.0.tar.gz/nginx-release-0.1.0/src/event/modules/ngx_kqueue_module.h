
/*
 * Copyright (C) Igor Sysoev
 */


#ifndef _NGX_KQUEUE_MODULE_H_INCLUDED_
#define _NGX_KQUEUE_MODULE_H_INCLUDED_


extern int                 ngx_kqueue;
extern ngx_module_t        ngx_kqueue_module;
extern ngx_event_module_t  ngx_kqueue_module_ctx;



#endif /* _NGX_KQUEUE_MODULE_H_INCLUDED_ */
