#ifndef MISC_H
#define MISC_H

int gettimeofday(struct timeval *,struct timezone *);

#endif
